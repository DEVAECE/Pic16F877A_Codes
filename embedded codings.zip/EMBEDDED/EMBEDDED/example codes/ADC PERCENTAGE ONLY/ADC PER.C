#include<pic.h>
void delay(unsigned int d)
{
	while(d--);
}
void command(unsigned char X)
{
	RE0=1;
    RE1=0;
	PORTD=X;
	delay(650);
	RE0=0;
}

void num(unsigned j)
{
int i=0;
int a[20];
while(j>0)
{
a[i]=j%10;
j=j/10;
i++;
}
i--;
while(i>=0)
{
RE0=1;
RE1=1;
PORTD=a[i]+0x30;

delay(650);
RE0=0;
i--;
}
}


void main()
{    
  TRISA=0XFF;
  PORTA=0X00;
  TRISE=0X00;
  TRISD=0X00;
  PORTE=0X00;
  PORTD=0X00;
  ADCON1=0x82;
  command(0X38);
  command(0X06);
  command(0X0C);
  command(0X01);
            
                   
while(1)                        //(128/1024)*100
{
    ADCON0=0xC5;
    while(ADIF==0);
     ADIF=0;
    int a=ADRESL;
    int b=ADRESH;    
    b=b<<8;
   int c=a+b;
       c=c*100;
       c=c/1023;       
    command(0Xc0);
    num(c);
                     
			}
}
           