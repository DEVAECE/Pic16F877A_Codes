#include<pic.h>
#include"lcd.h"
# include <htc.h>
__CONFIG (0x3F3A);
void delay (unsigned int d)
{
while (d--);
}
void command(int x)
{
   PORTE=0X04;	
   PORTD=x;
   delay(10000);
   RE2=0;
   
}
void data(char *x)
{
while(*x!='\0')
{
 PORTE=0x05;
 PORTD=*x;
 delay(10000);
 RE2=0;
 x++;
 delay(10000);
}
}
void num(int y)
{
	int remainder,a[10],i=0;
	PORTE=0X05;
	delay(10000);
	while(y>0)
	{
		remainder=y%10;
		a[i]=remainder;
		y=y/10;
		i++;
	}
	i--;
	while(i>=0)
	{
		a[i]=a[i]+0x30;
		delay(10000);
	    delay(200);
		RE2=1;
		PORTD=a[i];
		delay(10000);
		RE2=0;
		i--;
	}
}



void main()
{
	 int a,b,c;
	 TRISB=0X03;
	 TRISC=0X80;
	 TRISD=0X00;
	 TRISE=0X00;
	 TRISA=0xFF;
	 ADCON1=0x82;
  	 PORTC=0x00;
     PORTA=0x00;
     command(0x38);
 	 command(0x0c);
	 command(0x06);
   	 command(0x02);
  	 command(0x01);
     command(0x80);
	 data("HEALTH"); 
   
      

 while(1)
     {
        
         command(0x01);
         delay(10000);
         ADCON0=0XC5;				// AIR SENSOR
         delay(65000);
         delay(65000);
         ADGO=1;
         while(ADGO==1);
         int a=ADRESL;
         int b=ADRESH;
         b=b*256;
         int c=a+b;
         float sen=(c*0.0009775171065);
         int d=sen*100;
         d=d+20;
         command(0x80);
	     data(" AIR ");
         command(0xC0);
         num(c);

        
         delay(65000);
  
}
}
      
       


         