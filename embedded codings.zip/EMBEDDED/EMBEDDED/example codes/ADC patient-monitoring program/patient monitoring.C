#include<pic.h>
void delay(unsigned int d)
{
  while(d--);
}
void command(unsigned char X)
{
	RE0=1;
    RE1=0;
	PORTD=X;
	delay(650);
	RE0=0;
}
void data(unsigned char *p)
{
  while(*p!='\0')
  {
	RE0=1;
    RE1=1;
	PORTD=*p;
	delay(650);
	RE0=0;
	p++;

	}
}   

void num(unsigned int j)
{
int i=0;
int a[10];
while(j>0)
{
a[i]=j%10;
j=j/10;
i++;
}
i--;
while(i>=0)
{
RE0=1;
RE1=1;
PORTD=a[i]+0x30;
delay(650);
RE0=0;
i--;
}
}


void main()
{  
int TEMP,PRE,HB,GLU;  
 TRISA=0XFF;
 PORTA=0X00;
 TRISE=0X04;
 TRISD=0X00;
 PORTE=0X00;
 PORTD=0X00;
TRISC=0XFE;
PORTC=0X00;
 ADCON1=0x82;

 command(0X38);
 command(0X06);
 command(0X0C);
 command(0X01);
 command(0X80);
    
    command(0x80);
    data("TEMP");    // NORMAL BODY TEMP=97-99'F
    command(0x88);
    data("PRE");     //PRESSURE=80-120mmHg
    command(0xC0);
    data("HB");      //HEART BEAT RATE=60-100 
    command(0xC6);
    data("GLU");     
                      
while(1)
{
{     
   ADCON0=0xC5;
   while(ADIF==0);
   ADIF=0;
   int a=ADRESL;
   int b=ADRESH;    
   b=b<<8;
   int TEMP=a+b;
if(TEMP>200&&TEMP<300)    
   {         
    command(0X85);
    num(TEMP);
	}
else if(TEMP<200||TEMP>300)
{
   command(0X85);
    data("ABN");
	RC0=1;
    delay(65000);
	RC0=0;
   }
} 
{  
   ADCON0=0xCD;
   while(ADIF==0);
   ADIF=0;
   int a=ADRESL;
   int b=ADRESH;    
   b=b<<8;
   int PRE=a+b;
if(PRE>100&&PRE<200)     
   {             
    command(0X8C);
    num(PRE);
    }  
else if(PRE<100||PRE>200)
{
   command(0X8C);
    data("ABN");
	RC0=1;
    delay(65000);
	RC0=0;
   }  
}
{
  
   ADCON0=0xD5;
   while(ADIF==0);
   ADIF=0;
   int a=ADRESL;
   int b=ADRESH;    
   b=b<<8;
   int HB=a+b;
if(HB>70&&HB<85)     
   {              
    command(0XC3);
    num(HB);
	}
else if(HB<70||PRE>85)
{
   command(0XC3);
    data("ABN");
	RC0=1;
    delay(65000);
	RC0=0;
   }
}

{
       
   ADCON0=0xDD;
   while(ADIF==0);
   ADIF=0;
   int a=ADRESL;
   int b=ADRESH;    
   b=b<<8;
   int GLU=a+b;
if(GLU>300)     
   {         
    command(0XCA);
    num(GLU);
	}
else if(GLU<300)
{
   command(0XCA);
    data("EMP");
	RC0=1;
    delay(65000);
	RC0=0;
   }
}

{
if(RE2==1)
{
command(0XCE);
data("VD");
RC0=1;
delay(65000);
RC0=0;
}
}
}
}
           