#define First_Line 0x80
#define Second_Line 0xc0
#define Curser_On  0x0f
#define Curser_Off 0x0c
#define Clear_Display 0x01
#define ldata PORTD
#define rs RE0
#define RW RE1
#define en RE2
void Delay(unsigned int);
void Lcd8_Init();
void Lcd8_Command(unsigned char);
void Lcd8_write(unsigned char,unsigned char);
void Lcd8_Display(unsigned char ,const unsigned char * ,unsigned int);
void Lcd8_decimal2(unsigned char ,unsigned char );
void Lcd8_decimal3(unsigned char ,unsigned char );
void Lcd8_decimal4(unsigned char ,unsigned int );

 void Lcd8_Init()
 {
Lcd8_Command(0x38);
 Lcd8_Command(0x06);
 Lcd8_Command(0x0c);
 Lcd8_Command(0x01);
 }

void Lcd8_Command(unsigned char com)
{
	ldata=com;
	en=1;
RW=0;
	rs=0;
	Delay(5);
	en=0;
	Delay(5);
}
void Lcd8_write(unsigned char com,unsigned char q)
{
	Lcd8_Command(com);

	ldata=q;			// Data 
	en=1;
RW=0;
	rs=1;
	Delay(5);
	en=0;
	Delay(5);
}


void Lcd8_Display(unsigned char com,const unsigned char *word,unsigned int n)
{
	unsigned char lcd_i;

	for(lcd_i=0;lcd_i<n;lcd_i++)
	{ 
		Lcd8_write(com+lcd_i,word[lcd_i]);
  	}
}

 
void Lcd8_decimal2(unsigned char com,unsigned char val)
{
	unsigned int lcd_hr,lcd_t,lcd_o;

	lcd_hr=val%100;
	lcd_t=lcd_hr/10;
	lcd_o=lcd_hr%10;
	
	Lcd8_write(com,lcd_t+0x30);
	Lcd8_write(com+1,lcd_o+0x30);
}


void Lcd8_decimal3(unsigned char com,unsigned char val)
{
	unsigned int lcd_h,lcd_hr,lcd_t,lcd_o;

	lcd_h=val/100;
	lcd_hr=val%100;
	lcd_t=lcd_hr/10;
	lcd_o=lcd_hr%10;
	
	Lcd8_write(com,lcd_h+0x30);
	Lcd8_write(com+1,lcd_t+0x30);
	Lcd8_write(com+2,lcd_o+0x30);
}

void Lcd8_decimal4(unsigned char com,unsigned int val) 
{
	unsigned int lcd_th,lcd_thr,lcd_h,lcd_hr,lcd_t,lcd_o;

	val = val%10000;
	lcd_th=val/1000;
	lcd_thr=val%1000;
	lcd_h=lcd_thr/100;
	lcd_hr=lcd_thr%100;
	lcd_t=lcd_hr/10;
	lcd_o=lcd_hr%10;

	Lcd8_write(com,lcd_th+0x30);
	Lcd8_write(com+1,lcd_h+0x30);
	Lcd8_write(com+2,lcd_t+0x30);
	Lcd8_write(com+3,lcd_o+0x30);
}
void Delay(unsigned int x)
{
while(x--);	
}
