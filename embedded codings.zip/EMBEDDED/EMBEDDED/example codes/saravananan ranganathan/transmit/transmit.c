#include<pic.h>
#include"lcd.h"
# include <htc.h>
__CONFIG (0x3F3A);
unsigned char a4,loc[50],a1,a2,a3,w[10];
void delay(unsigned int x);
void uart_init();
unsigned int i,j,l;
char f,h;
unsigned int a,d2,d3;
unsigned int del,i,DL;
void call_delay()
{
for(DL=0;DL<10;DL++)
{   
	for(del=0;del<60000;del++);for(del=0;del<60000;del++);//for(del=0;del<60000;del++);
}
}
void call_delay1()
{
	for(del=0;del<60000;del++);for(del=0;del<60000;del++);	
}
void delay(unsigned int x)
{
 while(x--);
}
void TX(unsigned char z)
{
	TXREG=z;// Transmit buffer 8bit register
	while(TRMT!=1);// Tramsmit empty bit in TXSTA--used for checking whether TXREG is full or empty, if TRMT=1(empty) means TXIF will set as one
	TXIF=0;// Tx interrupt flag clear 
}
void send(unsigned char const *hh)
{
while(*hh){
		TX(*hh);		
		hh++;
}
}
void enter()
{
   TX(0x0d);//hex value for Carrage return--------------Refer ASCII table
   TX(0x0a);//hex value for new line or Enter--------------Refer ASCII table
	call_delay();

}
void send1(int m)
{
	int a=m/100;
	int b=(m%100)/10;
	int c=m%10;
	while(TRMT==0);
	TXREG=a+0x30;
	delay(10000);
	while(TRMT==0);
	TXREG=b+0x30;
	delay(10000);
    while(TRMT==0);
	TXREG=c+0x30;
	delay(10000);
    TXREG='\r';
}
void send2(unsigned char const *hh)
{
while(*hh){
 	while(TRMT==0);
	TXREG=*hh;
   
     delay(10000);
	hh++;
}
  TXREG='\r';
}
void gsm_init()
{
TXSTA=0X26;
 RCSTA=0X90;
 SPBRG=129;
send("AT");// Attention command to enable GSM modem
enter();/* Press enter command */

send("AT+CMGF=1"); //AT+CMGF	Message format
enter();

send("AT+CMGS=");//AT+CMGS	Send message
TX('"');//single character transmit function
send("9940273886");
TX('"');
enter();
send(" air ");
/*TX(f+0x30);
TX(h+0x30);*/
TX(0x1a);// 0x1a---ASCII value for Ctrl+z
call_delay();//call_delay();call_delay();
CREN=1;
}
 
void gsm1_init()
{
 TXSTA=0X26;
 RCSTA=0X90;
 SPBRG=129;
 delay(65000);
 delay(65000);
 send("AT");// Attention command to enable GSM modem
 enter();/* Press enter command */
 send("AT+CMGF=1"); //AT+CMGF	Message format
 enter();
  send("AT+CMGS=");//AT+CMGS	Send message
 TX('"');//single character transmit function
 send("9940273886");
 TX('"');
 enter();
 send(" PH ");
/* TX(f+0x30);
 TX(h+0x30);*/
 TX(0x1a);// 0x1a---ASCII value for Ctrl+z
 call_delay();//call_delay();call_delay();
 CREN=1;
}
 void gsm2_init()
{
 TXSTA=0X26;
 RCSTA=0X90;
 SPBRG=129;
 delay(65000);
 delay(65000);
 send("AT");// Attention command to enable GSM modem
 enter();/* Press enter command */
 send("AT+CMGF=1"); //AT+CMGF	Message format
 enter();
 send("AT+CMGS=");//AT+CMGS	Send message
 TX('"');//single character transmit function
 send("9940273886");
 TX('"');
 enter();
 send(" TEMP ");
 TX(0x1a);// 0x1a---ASCII value for Ctrl+z
 call_delay();//call_delay();call_delay();
 CREN=1;
}

void gsm3_init()
{
 TXSTA=0X26;
 RCSTA=0X90;
 SPBRG=129;
 delay(65000);
 delay(65000);
 send("AT");// Attention command to enable GSM modem
 enter();/* Press enter command */

 send("AT+CMGF=1"); //AT+CMGF	Message format
 enter();

 send("AT+CMGS=");//AT+CMGS	Send message
 TX('"');//single character transmit function
 send("9940273886");
 TX('"');
 enter();
 send(" GAS ");
/* TX(f+0x30);
 TX(h+0x30);*/
 TX(0x1a);// 0x1a---ASCII value for Ctrl+z
 call_delay();//call_delay();call_delay();
 CREN=1;
}
void uart_init()
{
	 TXSTA=0X26;
	 RCSTA=0X90;
	 SPBRG=129;
}

void command(int x)
{
   PORTE=0X04;	
   PORTD=x;
   delay(10000);
   RE2=0;
   
}
void data(char *x)
{
while(*x!='\0')
{
 PORTE=0x05;
 PORTD=*x;
 delay(10000);
 RE2=0;
 x++;
 delay(10000);
}
}
void num(int y)
{
	int remainder,a[10],i=0;
	PORTE=0X05;
	delay(10000);
	while(y>0)
	{
		remainder=y%10;
		a[i]=remainder;
		y=y/10;
		i++;
	}
	i--;
	while(i>=0)
	{
		a[i]=a[i]+0x30;
		delay(10000);
	    delay(200);
		RE2=1;
		PORTD=a[i];
		delay(10000);
		RE2=0;
		i--;
	}
}



void main()
{
	 int a,b,c;
	 TRISB=0X03;
	 TRISC=0X80;
	 TRISD=0X00;
	 TRISE=0X00;
	 TRISA=0xFF;
	 ADCON1=0x82;
  	 PORTC=0x00;
     PORTA=0x00;
     PORTB=0x00;
     uart_init();
     command(0x38);
 	 command(0x0c);
	 command(0x06);
   	 command(0x02);
  	 command(0x01);
     command(0x80);
	 data("HEALTH"); 
     GIE=1;
     PEIE=1;
     RCIE=1;
      
/*for(int i=0;i<5;i++)
    {
    while(TRMT==0);
    TXREG='q';
    delay(65000);
    }*/
 while(1)
     {
        
         command(0x01);
         delay(10000);
         ADCON0=0XC5;				// AIR SENSOR
         delay(65000);
         delay(65000);
         ADGO=1;
         while(ADGO==1);
         int a=ADRESL;
         int b=ADRESH;
         b=b*256;
         int c=a+b;
         float sen=(c*0.0009775171065);
         int d=sen*100;
        
         command(0x80);
	     data(" AIR ");
         command(0xC0);
         num(c);

         TXREG='d';
         delay(65000);
  		send1(c);

      
          delay(65000);


         command(0x01);			
         ADCON0=0XCD;				// PH SENSOR
         delay(65000);
         delay(65000);
         ADGO=1;
         while(ADGO==1);
         int a1=ADRESL;
         int b1=ADRESH;
         b1=b1*256;
         int c1=a1+b1;
         /*float sen1=(c1*0.0009775171065);
         int d1=sen1*100;*/
         
         command(0x84);
	     data(" PH ");
         command(0xC4);
         num(c1);
		
          TXREG='p';
          delay(65000);
           send1(c1);
        
delay(65000);

/*if(d1>30)
{
f=d1/10;
h=d1%10;
delay(65000);
delay(65000);
gsm1_init();
sending();
}*/



        command(0x01);
         ADCON0=0XD5;						// TEMP
         delay(65000);
         delay(65000);
         ADGO=1;
         while(ADGO==1);
         int a1=ADRESL;
         int b1=ADRESH;
         b1=b1*256;
         int c2=a1+b1;         
       	 float sen2=(c2*0.0009775171065);
         int d2=sen2*100;
         d2=d2+20;
         command(0x8A);
	     data(" TEMP ");
         command(0xCA);
         num(d2);		
          TXREG='e';
         delay(65000);
            send1(d2);   
delay(65000);


 command(0x01);
         ADCON0=0XDD;
         delay(65000);
         delay(65000);
         ADGO=1;
         while(ADGO==1);
         int a1=ADRESL;
         int b1=ADRESH;
         b1=b1*256;
         int c3=a1+b1;
         /*float sen3=(c3*0.0009775171065);
         int d3=sen3*100; */        
         command(0x8A);
	     data(" GAS ");
         command(0xCA);
         num(c3);			
          TXREG='g';
         delay(65000);
            send1(c3);   
delay(65000);

	if(c>50)	
	{
		command(0x80);
	    data("AIR POLLU ABNORMAL ");
		command(0xc0);
	    data("MSG SENDING ");
		delay(65000);
		gsm_init();
		delay(650);		
	}
	
if(c>30)	
	{
		command(0x80);
	    data("PH ABNORMAL ");
		command(0xc0);
	    data("MSG SENDING ");
		delay(65000);
		gsm_init();
		delay(650);		
	}

if(c>25)	
	{
		command(0x80);
	    data("TEMP ABNORMAL ");
		command(0xc0);
	    data("MSG SENDING ");
		delay(65000);
		gsm_init();
		delay(650);		
	}
if(c>15)	
	{
		command(0x80);
	    data("gas ABNORMAL ");
		command(0xc0);
	    data("MSG SENDING ");
		delay(65000);
		gsm_init();
		delay(650);		
	}
	}
}
 

   
      

