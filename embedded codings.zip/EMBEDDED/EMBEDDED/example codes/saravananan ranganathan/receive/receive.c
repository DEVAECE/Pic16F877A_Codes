#include<pic.h>
__CONFIG(0X3F3A);
void delay(unsigned int x);
unsigned int i,j,m=0;

	
void delay(unsigned int x)
{
 while(x--);
}
void command(int x)
{
   PORTE=0X04;	
   PORTD=x;
   delay(650);
   RE2=0;
   
}

void data(char *x)
{

while(*x!='\0')
{
 PORTE=0x05;
 PORTD=*x;
 delay(650);
 RE2=0;
 x++;
}
}
void num(int y)
{
	int remainder,a[10],i=0;

	while(y>0)
	{

		remainder=y%10;
		a[i]=remainder;
		y=y/10;
		i++;
	}
	i--;
	while(i>=0)
	{
        PORTE=0x05;
		a[i]=a[i]+0x30;
		RE2=1;
		PORTD=a[i];
		delay(650);
		RE2=0;
		i--;
						
	}
}
void receive(int z)
{
		if(i==0)
         {	
     	command(0xc1);
        data("  ");
         }
		if(i==3)
         {	
     	command(0xc5);
        data("  ");
         }
		if(i==6)
         {	
     	command(0xca);
        data("  ");

         }
	if(i==9)
         {	     
		i=0;
         }
       	command(0xc0+i);
        PORTE=0x05;
	    PORTD=z;
		delay(125);
		RE2=0;
        i++;
		
}

void interrupt isr()
{
unsigned char a;
while(RCIF==0);
RCIF=0;
 a=RCREG;
/* if(a=='q')
{
 m++;
} 
if(m>=5)
{*/
if(a=='d')
{

command(0x01);
command(0x80);
data("air");
command(0xc0);

}
else;
if(a=='p')
{
command(0x01);
command(0x83);
data("PH");
command(0xc0);

}
 else;	 
if(a=='e')
{

command(0x01);
command(0x86);
data("TEMP");
command(0xcA);

}
else;	 
if(a=='g')
{

command(0x01);
command(0x80);
data("GAS");
command(0xc0);

}
else;

if(a=='0'|| a=='1' ||a=='2'|| a=='3'|| a=='4' || a=='5'|| a=='6' || a=='7' ||a =='8' || a=='9') 
{
receive(a);
}
else;
}

 void main()
{
 TRISC=0x80;
 TRISD=0x00;
 TRISB=0X00;
 TRISE=0x00;
 ADCON1=0x82;
 PORTD=PORTB=0x00;
 PORTE=0x00; 
 PORTC=0x00;
 TXSTA=0X26;
 RCSTA=0X90;
 SPBRG=129;
 GIE=1;
 RCIE=1;
 PEIE=1;
 command(0x38);
	command(0x0c);
	command(0x06);
	command(0x02);
    command(0x01);
	delay(65000);
     command(0x80);
	 data("receiving");
 while(1)
{

}
}