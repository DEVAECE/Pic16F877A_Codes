#include<pic.h>
void delay (unsigned int d)
{
	while (d--);
	}
	void cmd (unsigned char x)
	{
		RB0=0;
		PORTD=x;
		RB1=1;
		delay(65000);
		RB1=0;
		}
		void data (unsigned char *y)
		{
			while (*y!='\0')
			{
				RB0=1;
				PORTD=*y;
				RB1=1;
				delay(65000);
				RB1=0;
				*y++;
				}
				}
				void n (int k)
				{
					PORTD=k+0x30;
					RB0=1;
					RB1=1;
					delay(65000);
					RB1=0;
				}
				void num (int j)
				{
					int  a[3],i=0;
					while(i<3)
					{
						a[i]=j%10;
						j=j/10;
						i++;
					}
					n(a[1]);
					n(a[0]);
					
					
				}	
					
						
							void main()
							{
								int i=0;
								int hour=0;
								int min=0;
								int sec=0;
								TRISD=0x00;
								TRISB=0x00;
								OPTION=0x87;
								TMR0=0;
								cmd(0x38);
								cmd(0x0c);
								cmd(0x01);
								cmd(0x80);
								data("hour");
								cmd(0xc0);
								num(hour);
								cmd(0x84);
								data("min");
								cmd(0xc4);
								num(min);
								cmd(0x87);
								data("sec");
								while(1)
								{
									while (T0IF==0);
									i++;
									T0IF=0;
									if (i==76)
									{
										cmd(0xc7);
										sec++;
										i=0;
										num(sec);
										}
										if (sec==60)
										{
											cmd(0xc4);
											min++;
											sec=0;
											num(min);
											}
											if (min==60)
											{
												cmd(0xc0);
												hour++;
												min=0;
												sec=0;
												num(hour);
												}
												}
												}
												
								
								
							
		