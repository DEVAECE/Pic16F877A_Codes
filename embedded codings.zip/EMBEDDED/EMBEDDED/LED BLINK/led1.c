#include<pic.h>
void delay(int x)
{
	while(x--);
}
void main()
{
	TRISC=0X00;
	PORTC=0X00;
	while(1)
	{
		PORTC=0X55;
		delay(65000);
		PORTC=0X00;
		delay(65000);
	}
}