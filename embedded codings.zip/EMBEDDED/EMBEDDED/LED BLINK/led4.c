#include<pic.h>
void delay(int x)
{
	while(x--);
}
void main()
{
	TRISC=0X00;
	PORTC=0X00;
	int a=0X01,b;
	while(1)
	{
		PORTC=a;
		delay(65000);
		b=a<<1;
		PORTC=b;
		delay(65000);
		if(b==0X80)
		{
			a=0XFF;
		}
		else if(a=0X00)
		{
			a=0X01;
		}
		else
		{
			a=b;
		}
	}
}