#include<pic.h>
#define latch RE0
#define r1 RD4
#define r2 RD5
#define r3 RD6
#define r4 RD7
#define c1 RB0
#define c2 RB1
#define c3 RB2
#define c4 RB3
void main()
{
	ADCON1=0x8E;
	TRISD=0x00;
	PORTD=0x00;
	TRISE=0x00;
	PORTE=0x00;
	TRISB=0x0f;
	PORTB=0x00;
	latch=1;
	while(1)
	{r1=0;r2=r3=r4=1;
		if(c1==0)
		{PORTD=0x01;
			}
			if(c2==0)
			{PORTD=0x02;
				}
				if(c3==0)
				{PORTD=0x03;
					}
					if(c4==0)
					{PORTD=0X04;
						}
						r2=0;r1=r3=r4=1;
						if(c1==0)
		{PORTD=0x05;
			}
			if(c2==0)
			{PORTD=0x06;
				}
				if(c3==0)
				{PORTD=0x07;
					}
					if(c4==0)
					{PORTD=0X08;
						}
							r3=0;r1=r2=r4=1;
							
					if(c1==0){PORTD=0x09;}
			if(c2==0)
			{PORTD=0x02;
				}
				if(c3==0)
				{PORTD=0x03;
					}
					if(c4==0)
					{PORTD=0X04;
						}
							r4=0;r1=r2=r3=1;
								if(c1==0)
								{PORTD=0x01;
									}
			if(c2==0)
			{PORTD=0x02;
				}
				if(c3==0)
				{PORTD=0x03;
					}
					if(c4==0)
					{PORTD=0X04;
						}
					}
}
	