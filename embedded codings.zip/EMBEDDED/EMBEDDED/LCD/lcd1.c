#include<pic.h>
#define RS RC0
#define E RC1
#define S1 RC2
#define S2 RC3
#define S3 RC4
void delay(unsigned int x)
{
	while(x--);
}
void command(unsigned int z)
{
		RS=0;
		E=1;
		PORTD=z;
		delay(650);
		E=0;
}
void data(unsigned char *dat)
{
	while(*dat!='\0')
	{
		RS=1;
		E=1;
		PORTD=*dat;
		delay(650);
		E=0;
		dat++;
	}
}
void main()
{  
	TRISC=0XFC;
	PORTC=0X00;
	TRISD=0X00;
	PORTD=0X00;
	command(0X38);
	command(0X06);
	command(0X0C);
	command(0X01);
			while(1)
			{
				if(S1==0&&S2==0&&S3==0)
				{
					command(0X80);
					data("DEVAPRASATH");
					delay(65000);
				}
				if(S1==1&&S2==0&&S3==0)
				{
					command(0X80);
					data("ECE STUDENT");
					delay(65000);
				}
		    	if(S1==0&&S2==1&&S3==0)
				{
					command(0X80);
					data("JIT");
					delay(65000);
				}
				if(S1==0&&S2==0&&S3==1)
				{
					command(0X80);
					data("SALEM");
					delay(65000);
				}
				command(0X01);
			}

}
	