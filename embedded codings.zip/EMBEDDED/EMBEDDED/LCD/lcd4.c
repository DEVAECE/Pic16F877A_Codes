#include<pic.h>
#define RS RC0
#define E RC1
#define S1 RC2
#define S2 RC3
void delay(unsigned int x)
{
	while(x--);
}
void command(unsigned int z)
{
	RS=0;
	E=1;
	PORTD=z;
	E=0;
	delay(650);
}
void num(unsigned int k)
{	int i=0;
	int a[10];
	while(k>0)
	{
		a[i]=k%10;
		k=k/10;
		i++;
	}
	i--;
	while(i>=0)
	{
		RS=1;
		E=1;
		PORTD=a[i]+0X30;
		E=0;
		delay(650);
		i--;
	}
}

void main()
{
	TRISC=0XFC;
	PORTC=0X00;
	TRISD=0X00;
	PORTD=0X00;
	command(0x38);
	command(0X06);
	command(0X0C);
	command(0X01);
	int i;
while(1)
{
	if(S1==1&&S2==0)
	{	i=1;
		while(i!=11)
		{
		 num(i);
		delay(65000);
		i++;
		}
		
	}
	if(S1==0&&S2==1)
	{	i=10;
		while(i!=0)
		{
		 num(i);
		delay(65000);
		i--;
		}
	}
	command(0X01);
}
}