#include<pic.h>
#define RS RC0
#define E RC1
void delay(unsigned int x)
{
	while(x--);
}
void command(unsigned int z)
{
		RS=0;
		E=1;
		PORTD=z;
		delay(650);
		E=0;
}
void data(unsigned char *dat)
{
	while(*dat!='\0')
	{
		RS=1;
		E=1;
		PORTD=*dat;
		delay(650);
		E=0;
		dat++;
	}
}
void num(unsigned int j)
{
	int i=0;
	int a[10];
	while(j>0)
	{
		a[i]=j%10;
		j=j/10;
		i++;
	}
	i--;
	while(i>=0)
	{
		RS=1;
		E=1;
		PORTD=a[i]+0X30;
		delay(650);
		E=0;
		i--;
	}
}
		
void main()
{
	TRISC=0X00;
	PORTC=0X00;
	TRISD=0X00;
	PORTD=0X00;
	command(0X38);
	command(0X06);
	command(0X0C);
	command(0X01);
	while(1)
	{
	/*command(0X80);
		data("DEVAPRASATH");
		delay(65000);*/
		command(0x80);
		num(965);
		delay(65000);
	}
	
}
	