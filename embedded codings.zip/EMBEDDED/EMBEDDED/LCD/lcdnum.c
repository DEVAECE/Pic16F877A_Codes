#include<pic.h>
void delay(unsigned int x)
{
	while(x--);
}
void command(unsigned int z)
{
	RC0=0;
	PORTD=z;
	RC1=1;
	delay(65000);
	RC1=0;
}
void num(unsigned int j)
{
	int i=0;
	int a[3];
	while(i<3)
	{
		a[i]=j%10;
		j=j/10;
		i++;
	}
	i--;
	while(i>=0)
	{
		RC0=1;
		PORTD=a[i]+0X30;
		RC1=1;
		delay(65000);
		RC1=0;
		i--;
	}
}
void data(unsigned char *dat)
{
	while(*dat!='\0')
	{
		RC0=1;
		PORTD=*dat;
		RC1=1;
		delay(65000);
		RC1=0;
		*dat++;
	}
}
void main()
{
	TRISC=0X00;
	PORTC=0X00;
	TRISD=0X00;
	PORTD=0X00;
	command(0X38);
	command(0X06);
	command(0X0C);
	command(0X01);
	command(0X80);
	data("number is");
	int k=0;
	while(k<=100)
	{
	command(0XC0);
	num(k);
	k++;
	}
}
