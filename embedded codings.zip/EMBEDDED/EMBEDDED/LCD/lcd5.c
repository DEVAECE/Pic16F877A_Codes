#include<pic.h>
#define RS RC0
#define E RC1
#define S1 RC2
#define S2 RC3
void delay(unsigned int x)
{
	while(x--);
}
void command(unsigned int z)
{
	RS=0;
	E=1;
	PORTD=z;
	E=0;
	delay(650);
}
void num(unsigned int k)
{	int i=0;
	int a[10];
	while(k>0)
	{
		a[i]=k%10;
		k=k/10;
		i++;
	}
	i--;
	while(i>=0)
	{
		RS=1;
		E=1;
		PORTD=a[i]+0X30;
		E=0;
		delay(650);
		i--;
	}
}

void main()
{
	TRISC=0XFC;
	PORTC=0X00;
	TRISD=0X00;
	PORTD=0X00;
	command(0x38);
	command(0X06);
	command(0X0C);
	command(0X01);
	static int k=0;
	while(1)
	{
	if(S1==1&&S2==0)
	{	 k+=1;
		command(0X80);
		 num(k);
		delay(65000);
	while(S1==1&&S2==0);
	}
		
	if(S1==0&&S2==1)
	{	 k-=1;
		command(0X80);
		 num(k);
		delay(65000);
while(S1==0&&S2==1);
	}
	}
}
