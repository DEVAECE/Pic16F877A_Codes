#include<pic.h>
void delay(unsigned int x)
{
	while(x--);
}
void command(unsigned int z)
{
	RC0=0;
	PORTD=z;
	RC1=1;
	delay(650);
	RC1=0;
}
void data(unsigned char *dat)
{
	while(*dat!='\0')
	{
		RC0=1;
		PORTD=*dat;
		RC1=1;
		delay(65000);
		RC1=0;
		*dat++;
	}
}
void num(unsigned int j)
{
	int i;
	int a[2];
	for(i=0;i<2;i++)
	{
		a[i]=j%10;
		j=j/10;
	}
	print(a[1]);
	print(a[0]);
}
void print(int k)
{
		RC0=1;
		PORTD=k+0X30;
		RC1=1;
		delay(65000);
		RC1=0;
}
void main()
{
	TRISC=0X00;
	PORTC=0X00;
	PORTD=0X00;
	TRISD=0X00;
	TRISB=0X00;
	PORTB=0X00;
	command(0X38);
	command(0X06);
	command(0X0C);
	command(0X01);
	int count=0,sec,min,hr;
	OPTION=0X87;
	TMR0=0X00;
	while(1)
	{	
	sec=0;
	min=0;
	hr=0;
	
			while(T0IF==0);
			T0IF=0;
			count=count++;
		if(count==76)
		{
			sec=sec+1;
			PORTB=~PORTB;
			T0IF=1;
		}
		if(sec==60)
		{
			min=min+1;
			sec=0;	
		}
		if(min==60)
		{
			hr=hr+1;
			min=0;
			sec=0;
		}
		if(hr==24)
		{
			hr=0;
		}
		command(0X80);
		num(hr);
		command(0X82);
		data(":");
		command(0X83);
	    num(min);
		command(0X85);
		data(":");
		command(0X86);
		num(sec);
		command(0X01);
	}
}
		
			
		
		