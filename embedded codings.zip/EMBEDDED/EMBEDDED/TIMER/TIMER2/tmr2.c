#include<pic.h>
void main()
{
	int i=0;
	T2CON=0X87;
	TRISB=0X00;
	PORTB=0X00;
	TMR2=0;
	PR2=250;
	
while(1)
{
	while(TMR2IF==0);
	i=i++;
	TMR2IF=0;
	if(i==76)
	{
		PORTB=~PORTB;
		i=0;
	}
}
}
	