#include<pic.h>
void delay(unsigned int x)
{
	while(x--);
}
void command(unsigned int z)
{
	RC0=0;
	PORTD=z;
	RC1=1;
	delay(65000);
	RC1=0;
}
void data(unsigned char *dat)
{
	while(*dat!='\0')
	{
	RC0=1;
	PORTD=*dat;
	RC1=1;
	delay(65000);
	RC1=0;
	*dat++;
	}
}
void num(int j)
{
	int a[2],i=0;
	while(i<2)
	{
		a[i]=j%10;
		j=j/10;
		i++;
	}
	i--;
	while(i>=0)
	{
		RC0=1;
		PORTD=a[i]+0x30;
		RC1=1;
		delay(65000);
		RC1=0;
		i--;
	}
}
void main()
{
	TRISC=0X00;
	PORTB=0X00;
	PORTD=0X00;
	TRISD=0X00;
	int i=0;
	TMR0=0X00;
	OPTION=0X87;
	int sec=0;
	int min=0;
	int hour=0;
	int day=0;
	command(0X38);
	command(0X06);
	command(0X0c);
	command(0X01);
	command(0XC0);
	data("day:");
	command(0XC5);
	num(day);
	command(0x80);
    num(hour);
	command(0x83);
	data(":");
	command(0x84);
	num(min);
	command(0x87);
 	data(":");
	command(0x88);
	num(sec);
	while(1)
	{
		while(T0IF==0);
		T0IF=1;
		i=i++;
		if(i==76)
		{
			command(0x88);
			sec++;
			i=0;
			num(sec);
		}
		if(sec==60)
		{
			command(0x84);
			min++;
			sec=0;
			num(min);
		}
		if(min==60)
		{
			command(0x80);
			hour++;
			min=0;
			sec=0;
		    num(hour);
		 }
		 if(hour==24)
		 {
			 command(0XC5);
			 day++;
			 hour=0;
			 min=0;
			 sec=0;
			 num(day);
		  }
	}
}
			
			
		