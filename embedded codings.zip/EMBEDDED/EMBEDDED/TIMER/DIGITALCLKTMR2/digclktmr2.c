#include<pic.h>
void delay(unsigned int x)
{
	while(x--);
}
void command(unsigned int z)
{
	RC0=0;
	PORTD=z;
	RC1=1;
	delay(65000);
	RC1=0;
}
void data(unsigned char *dat)
{
	while(*dat!='\0')
	{
		RC0=1;
		PORTD=*dat;
		RC1=1;
		delay(65000);
		RC1=0;
		*dat++;
	}
}
void num(unsigned int j)
{
	int i=0;
	int a[2];
	while(i<2)
	{
		a[i]=j%10;
		j=j/10;
		i++;
	}
	i--;
	while(i>=0)
	{
		RC0=1;
		PORTD=a[i]+0X30;
		RC1=1;
		delay(65000);
		RC1=0;
		i--;
	}
}
void main()
{
	int i=0;
	int hour=0;
	int min=0;
	int sec=0;
	TRISD=0X00;
	PORTD=0X00;
	TRISC=0X00;
	PORTC=0X00;
	command(0X38);
	command(0X06);
	command(0X0C);
	command(0X01);
	command(0X80);
	num(hour);
	command(0X83);
	data(":");
	command(0X84);
	num(min);
	command(0X87);
	data(":");
	command(0X88);
	num(sec);
	T2CON=0X87;
	TMR2=0;
	PR2=250;
while(1)
{
	while(TMR2IF==0);
	TMR2IF=0;
	i=i++;
	if(i==76)
	{
		sec=sec++;
		i=0;
		command(0X88);
		num(sec);
	}
	if(sec==60)
	{
		min=min++;
		sec=0;
		command(0X84);
		num(min);
	}
	if(min==60)
	{
		hour=hour++;
		min=0;
		command(0X80);
		num(hour);
	}
}
}