#include<pic.h>
void delay(unsigned int x)
{
	while(x--);
}
void command(unsigned int z)
{
	RE0=0;
	PORTD=z;
	RE1=1;
	delay(65000);
	RE1=0;
}
void data(unsigned char *dat)
{
	while(*dat!='\0')
	{
		RE0=1;
		PORTD=*dat;
		RE1=1;
		delay(65000);	
		RE1=0;
		dat++;
	}
}
void interrupt isr()
{
	if(RBIF==1)
	{
		if(RB4==1)
		{
			command(0X80);
			data("CALIBER");
			delay(650);
	

		}
		command(0x01);
	}
	RBIF=0;		
}
void main()
{
	int a,i;
	TRISD=0X00;
	PORTD=0X00;
	TRISC=0X00;
	PORTC=0X00;
	ADCON1=0X82;
	TRISE=0X00;
	PORTE=0X00;
	TRISB=0XFF;
	PORTB=0X00;
	command(0X38);
	command(0X06);
	command(0X0C);
	command(0X01);
	GIE=1;
	PEIE=1;
	INTE=1;
    RBIE=1;
	//INTCON=0XD0;
	while(1)
	{
		a=0X01;
		for(i=0;i<=7;i++)
		{
			PORTC=a;
			a=a<<1;
			delay(65000);
			delay(65000);
		}
		a=0X80;
		for(i=0;i<=7;i++)
		{
			PORTC=a;
			a=a>>1;
			delay(65000);
			delay(65000);
		}
	}
}
		

	