
4#include<pic.h>
void delay(int x)
{
	while(x--);
}
void main()
{
	TRISC=0X00;
	PORTC=0X00;
	int i,a;
	while(1)
	{	a=0X01;
		for(i=0;i<=7;i++)
		{
			PORTC=a;
			a=a<<1;
			delay(65000);
		}
		a=0X80;
		for(i=0;i<=7;i++)
		{
			PORTC=a;
			a=a>>1;
			delay(65000);
		}
	}
}