#include<pic.h>
#define latch RE0
#define r1 RB4
#define r2 RB5
#define r3 RB6
#define r4 RB7
#define c1 RC0
#define c2 RC1
#define c3 RC2
#define c4 RC3
void delay(unsigned int x)
{
	while(x--);
}
void command(unsigned int z)
{
	RE0=0;
	PORTD=z;
	RE1=1;
	delay(65000);
	RE1=0;
}
void data(unsigned char *dat)
{
	while(*dat!='\0')
	{
		RE0=1;
		PORTD=*dat;
		RE1=1;
		delay(65000);
		RE1=0;
		dat++;
	}
}
void num(unsigned int j)
{
	int i=0;
	int a[1];
	while(i<1)
	{
		a[i]=j%10;
		j=j/10;
		i++;
	}
	i--;
	while(i>=0)
	{
		RE0=1;
		PORTD=a[i]+0X30;
		RE1=1;
		delay(65000);
		RE1=0;
	}
}
			
void main()
{
	ADCON1=0x82;
	TRISD=0x00;
	PORTD=0x00;
	TRISE=0x00;
	PORTE=0x00;
	TRISC=0x00;
	PORTC=0x00;
	TRISB=0X00;
	PORTB=0X00;
	command(0X38);
	command(0X06);
	command(0X0C);
	command(0X01);
	while(1)
	{
		r1=0;r2=r3=r4=1;
		if(c1==0)
			{
				num(7);
				command(0X01);
			}
		if(c2==0)
			{
				num(4);
				command(0X01);
			}	
		if(c3==0)
			{
				num(7);
				command(0X01);
			}
		if(c4==0)
			{
				num(4);
				command(0X01);
			}


		r2=0;r1=r3=r4=1;
		if(c1==0)
			{
				num(7);
				command(0X01);
			}
		if(c2==0)
			{
				num(4);
				command(0X01);
			}	
		if(c3==0)
			{
				num(7);
				command(0X01);
			}
		if(c4==0)
			{
				num(4);
				command(0X01);
			}	


		r3=0;r2=r1=r4=1;
		if(c1==0)
			{
				num(7);
				command(0X01);
			}
		if(c2==0)
			{
				num(4);
				command(0X01);
			}	
		if(c3==0)
			{
				num(7);
				command(0X01);
			}
		if(c4==0)
			{
				num(4);
				command(0X01);
			}	
	

        r4=0;r1=r3=r2=1;
		if(c1==0)
			{
				num(7);
				command(0X01);
			}
		if(c2==0)
			{
				num(4);
				command(0X01);
			}	
		if(c3==0)
			{
				num(7);
				command(0X01);
			}
		if(c4==0)
			{
				num(4);
				command(0X01);
			}	
	}
}
	
	