#include<pic.h>
void delay(unsigned int x)
{
	while(x--);
}
void interrupt isr()
{
	if(RBIF==1)
	{
		if(RB4==1)
		{
		RC0=1;
		delay(65000);
		delay(65000);
		RC0=0;
		delay(65000);
		}

	}
	RBIF=0;	
}
	
void main()
{
	int i=0,a;
	PORTD=0X00;
	TRISD=0X00;
	PORTC=0X00;
	TRISC=0X00;
	TRISB=0XFF;
	PORTB=0X00;
	INTCON=0XC8;
	while(1)
	{
		a=0X01;
		for(i=0;i<8;i++)
		{
			PORTD=a;
			a=a<<1;
			delay(65000);
		}
		a=0X80;
		for(i=8;i>0;i--)
		{
			PORTD=a;
			a=a>>1;
			delay(65000);
		}
	}
}

		