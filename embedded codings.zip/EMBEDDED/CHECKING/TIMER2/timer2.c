#include<pic.h>
void main()
{
	int i=0;
	TRISB=0X00;
	PORTB=0X00;
	T2CON=0X7F;
	PR2=0XFF;
	TMR2=0X00;
	while(1)
	{
		while(!TMR2IF);
		TMR2IF=0;
		i=i++;
		if(i==77)
		{
			PORTB=~PORTB;
			i=0;
		}
	}
}
