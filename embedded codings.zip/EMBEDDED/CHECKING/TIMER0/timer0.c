#include<pic.h>
void main()
{
	int i=0;
	TRISB=0X00;
	PORTB=0X00;
	OPTION=0X87;
	TMR0=0;
	while(1)
	{
		while(!T0IF);
		i=i++;
		T0IF=0;
		if(i==76)
		{
			PORTB=~PORTB;
			i=0;
		}
	}
}