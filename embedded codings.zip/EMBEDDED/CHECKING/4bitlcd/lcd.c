#include<pic.h>
void delay(unsigned int x)
{
	while(x--);
}

void command(unsigned char z)
{
	RB0=0;
	PORTD=(z&0XF0);
	RB1=1;
	delay(650);
	RB1=0;
	PORTD=((z<<4)&0XF0);
	RB1=1;
	delay(650);
	RB1=0;
}
void command1(unsigned char z)
{
	RB0=0;
	PORTC=(z&0XF0);
	RB1=1;
	delay(650);
	RB1=0;
	PORTC=((z<<4)&0XF0);
	RB1=1;
	delay(650);
	RB1=0;
}
void lcd_init()
{
	RB0=0;
	PORTD=0X20;
	PORTC=0X20;
	RB1=1;
	delay(650);
	RB1=0;
	command(0X28);
	command(0X06);
	command(0X02);
	command(0X0C);
	command(0X80);
	command(0X01);
	command1(0X28);
	command1(0X06);
	command1(0X02);
	command1(0X0C);
	command1(0X80);
	command1(0X01);
	
}
void data(unsigned char *dat)
{	while(*dat!='\0')
	{
		RB0=1;
		PORTD=(*dat&0XF0);
		RB1=1;
		delay(650);
		RB1=0;
		PORTD=((*dat<<4)&0XF0);
		RB1=1;
		delay(650);
		RB1=0;
		dat++;
	}
}
void data1(unsigned char *dat)
{	while(*dat!='\0')
	{
		RB0=1;
		PORTC=(*dat&0XF0);
		RB1=1;
		delay(650);
		RB1=0;
		PORTC=((*dat<<4)&0XF0);
		RB1=1;
		delay(650);
		RB1=0;
		dat++;
	}
}
void num(unsigned int L)
{
	int i=0;
	int A[4];
	while(i<4)
	{
		A[i]=L%10;
		L=L/10;
		i++;
	}
	i--;
	while(i>=0)
	{
		RB0=1;
		PORTD=((A[i]+0X30)&0XF0);
		RB1=1;
		delay(65000);
		RB1=0;
		PORTD=(((A[i]+0X30)<<4)&0XF0);
		RB1=1;
		delay(65000);
		RB1=0;
		i--;
	}
}
void num1(unsigned int k)
{
	int i=0;
	int A[4];
	while(i<4)
	{
		A[i]=k%10;
		k=k/10;
		i++;
	}
	i--;
	while(i>=0)
	{
		RB0=1;
		PORTC=((A[i]+0X30)&0XF0);
		RB1=1;
		delay(65000);
		RB1=0;
		PORTC=(((A[i]+0X30)<<4)&0XF0);
		RB1=1;
		delay(65000);
		RB1=0;
		i--;
	}
}
	

void main()
{
	TRISD=0X00;
	PORTD=0X00;
	TRISC=0X00;
	PORTC=0X00;
	TRISB=0X00;
	PORTB=0X00;
	TRISA=0X3F;
	PORTA=0X00;
	lcd_init();
	ADCON1=0X84;
	int a,b,c,a1,b1,c1,d,d1;
	float e,e1;
	while(1)
	{
		ADCON0=0XC5;
		ADGO=1;
		while(!ADGO);
		a=ADRESH;
		b=ADRESL;
		a=a<<8;
		c=a+b;
		e=c/1023;
		d=e*100;
		command(0X80);
		data("SENSOR2");
		command(0XC0);
		num(c);
		delay(65000);
		command(0X01);

		ADCON0=0XCD;
		ADGO=1;
		while(!ADGO);
		a1=ADRESH;
		b1=ADRESL;
		a1=a1<<8;
		c1=a1+b1;
		e1=c1/1023;
		d1=e1*100;
		command1(0X80);
		data1("SENSOR1");
		command1(0XC0);
		num1(c1);
		delay(65000);
		command1(0X01);
	}
}
	
	