#include<pic.h>
void delay(unsigned int x)
{
	while(x--);
}
void command(unsigned int z)
{
	RC0=0;
	RC1=1;
	PORTD=z;
	RC1=0;
	delay(65000);
}
void data(unsigned char *dat)
{
	while(*dat!='\0')
	{
	RC0=1;
	RC1=1;
	PORTD=*dat;
	RC1=0;
	delay(65000);
	dat++;
	}
}
void num(unsigned int j)
{
	int i=0;
	int a[4];
	while(j>0)
	{
		a[i]=j%10;
		j=j/10;
		i++;
	}
	i--;
	while(i>=0)
	{
		a[i]=a[i]+0X30;
		RC0=1;
		RC1=1;
		PORTD=a[i];
		RC1=0;
		delay(650);
		i--;
	}
}
void main()
{
	int a,b,c,e;
	TRISA=0XFF;
	TRISB=0X00;
	TRISD=0X00;
	PORTD=0X00;
	TRISC=0X00;
	PORTC=0X00;
	command(0X38);
	command(0X06);
	command(0X0C);
	command(0X01);
	ADCON1=0X80;
	while(1)
	{
		ADCON0=0XC5;
		ADGO=1;
		while(ADGO==1);
		a=ADRESH;
		b=ADRESL;
		b=b<<8;
		c=a+b;
	/*float d=(c*0.000977517107);
		e=d*100;*/
		command(0XC0);	
		num(c);
		delay(65000);
	}
}