#include<pic.h>
void delay(unsigned int x)
{
	while(x--);
}
void command(unsigned int z)
{
	RC0=0;
	PORTD=z;
	RC1=1;
	RC2=1;
	delay(65000);
	RC1=0;
	RC2=0;
}
void num(unsigned int j)
{
	int i=0;
	int a[10];
	while(j>0)
	{
		a[i]=j%10;	
		j=j/10;
		i++;
	}
	i--;
	while(i>=0)
	{
		RC0=1;
		PORTD=a[i]+0x30;
		RC1=1;
		delay(65000);
		RC1=0;
		i--;
	
	}
}
void num1(unsigned int k)
{
	int i=0;
	int b[10];
	while(k>0)
	{
		b[i]=k%10;
		k=k/10;
		i++;
	}
	i--;
	while(i>=0)
	{
		RC0=1;
		RC2=1;
		PORTD=b[i]+0x30;
		delay(65000);
		RC2=0;
		i--;
	}
}
	

void main()
{
	int a,a1,b,b1,c,c1,d;
	TRISA=0XFF;
	TRISC=0X00;
	PORTC=0X00;
	PORTD=0X00;
	TRISD=0X00;
	ADCON1=0X80;
	command(0X38);
	command(0X06);
	command(0X0C);
	command(0X01);
	while(1)
	{
		ADCON0=0XC5;
		ADGO=1;
		while(ADGO==1);
		a=ADRESH;
		b=ADRESL;
		b=b<<8;
		c=a+b;
		command(0X80);
		num(c);
		ADCON0=0XCD;
		ADGO=1;
		while(ADGO==1);
		a1=ADRESH;
		b1=ADRESL;
		b1=b1<<8;
		c1=a1+b1;
		command(0X80);
        num1(c1);
	}
}
	
	
		
	