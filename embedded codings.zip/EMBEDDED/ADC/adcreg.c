#include<pic.h>
void main()
{
	 int a,b,c;
	TRISA=0XFF;
	TRISB=0X00;
	ADCON1=0X80;
	while(1)
	{
		ADCON0=0XC5;
		ADGO=1;
		while(ADGO==1);
		a=ADRESH;
		b=ADRESL;
		b=b<<8;
		c=a+b;
		if(c>=512)
		{
			PORTB=0XFF;
		}
		else
		{
			PORTB=0X00;
		}
	}
}