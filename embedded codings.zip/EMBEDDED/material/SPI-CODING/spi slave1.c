#include<pic.h>
#include"lcd.h"
unsigned int i=0;
void spi_setting(void)
{
	ADCON1=0x82;
	TRISC4=1;
	TRISC5=0;
	TRISC3=1;
	TRISA5=1;
	//TRISC0=0;
	//TRISC1=0;
	//TRISC2=0;
	//PORTC=0x00;
	SSPSTAT = 0x40; // data is sampled in middle of o/p
    SSPCON = 0x24;  //spi slave mode, 
}
void main()
{
	TRISD=0x00;
	TRISE=0x00;
	PORTE=0x00;
	PORTD=0x00;
	TRISB=0x00;
	PORTB=0x00;
	unsigned int i=0,a;
	unsigned char b=0xc0;
	spi_setting();
    lcd_init();
    lcd_command(0x38);
    lcd_command(0x0c);
    lcd_command(0x06);
    lcd_command(0x02);
    lcd_command(0x80);
    lcd_data("slave");
	while(1)
	{
        while(BF==0); //wait till complete
		a=SSPBUF;
		lcd_command(b);
        lcd_data1(a);
		delay(6500);
		delay(6500);
		b++;
 	
     }
 lcd_command(0x01);
}