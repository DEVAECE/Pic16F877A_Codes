#include<pic.h>
unsigned char d[16];
unsigned int i;
void uart_init()
 {
  TRISC6=0;
  TRISC7=1;
  TXSTA=0X26;
  RCSTA=0X90;
  SPBRG=129;
 }
void uart_tx(unsigned char z)
 {
  while(TRMT==0);
  TXREG=z;
  delay(50000);
 }
void uart_datatx(unsigned char *y)
 {
   while(*y!='\0')
   {
    while(TRMT==0);
    TXREG=*y;
    delay(50000);
    y++;
   }
 }
void uart_space()
 {
  while(TRMT==0);
  TXREG='\r';
 }
void uart_rc()
 {
   while(RCIF==0);
   RCIF=0;
   d[i]=RCREG;
   lcd_command(0x80+i);
   lcd_data1(d[i]);
   i++;
    if(d[0]=='s'&&d[1]=='e'&&d[2]=='n'&&d[3]=='t'&&d[4]=='h'&&d[5]=='i'&&d[6]=='l')
     { 
      i=0;
      lcd_command(0xc0);
      lcd_data("priya");
     }
  if(d[0]=='p'&&d[1]=='r'&&d[2]=='i'&&d[3]=='y'&&d[4]=='a')
  {
       i=0;
      lcd_command(0xc0);
      lcd_data("senthil");
  }
if(d[0]=='e'&&d[1]=='n'&&d[2]=='t'&&d[3]=='h'&&d[4]=='i'&&d[5]=='l')
     { 
      i=0;
      lcd_command(0xc0);
      lcd_data("kumar");
     }
 }