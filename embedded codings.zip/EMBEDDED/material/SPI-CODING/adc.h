#include<pic.h>
void adc_init()
 {
	  TRISA=0xFF;
	 
 }
void adc()
{
 ADCON0=0xC5;
 ADGO=1;
 while(ADGO==1);
 int a=ADRESL;
 int b=ADRESH;
 b=b*256;
 int c=a+b;
 float sen=(c*0.00097752);
 int d=sen*100;
 lcd_num(d);
}
void adc1()
{
 ADCON0=0xCD;
 ADGO=1;
 while(ADGO==1);
 int a=ADRESL;
 int b=ADRESH;
 b=b*256;
 int c=a+b;
 float sen=(c*0.00097752);
 int d=sen*100;
 lcd_num(d);
}