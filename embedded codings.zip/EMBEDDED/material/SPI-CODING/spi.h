#include<pic.h>
void spi_setting()
{
	ADCON1=0x86;
	TRISC4=1;
	TRISC5=0;
	TRISC3=0;
	TRISA=0x00;
	SSPSTAT =0x40; // data is sampled in middle of o/p
    SSPCON =0x20;  //spi master mode, fosc/4
}
void spi_tx(unsigned char *j)
{
    while(*j!='\0')
   {
    SSPSTAT =0x40;
	while(BF == 1); //wait till complete
	SSPBUF =*j;  // write data
	while(BF);
    delay(65000);
	delay(65000);
   //SSPSTAT =0x00;
    j++;
   }
}	
