#include<pic.h>
#include"lcd.h"
#include"spi.h"
unsigned int i=0;

void main()
{
    lcd_init();
    spi_setting();
    lcd_command(0x38);
    lcd_command(0x0c);
    lcd_command(0x06);
    lcd_command(0x02);
    lcd_command(0x80);
    lcd_data("MASTER");
	while(1)
	{
        lcd_command(0x80);
        lcd_data("MASTER");
        RA3=1;
        RA2=0;
        delay(65000);
	    delay(65000);
     	delay(65000);
        spi_tx("CALIBER");
        lcd_command(0xC0);
        lcd_data("DATA1 SEND");
        lcd_command(0x01); 
        RA2=1;
        RA3=0;
        delay(65000);
	    delay(65000);
     	delay(65000);
        spi_tx("EMBEDDED");
        lcd_command(0xc0);
        lcd_data("DATA2 SEND");  
        lcd_command(0x01); 
   }
}