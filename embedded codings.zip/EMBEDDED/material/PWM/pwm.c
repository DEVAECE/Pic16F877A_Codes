#include<pic.h>
void main()
{
	TRISC=0x00;
	TRISA=0xff;
	TMR2=0x00;
	T2CON=0b00000111;
	PR2=	0b11111111;
	ADCON0=0XC5;
	ADCON1=0X82;
	CCP1CON=0b00111100;
//	CCP1CON=0x3c;
	while(1)
	{
		while(ADGO==1);
		ADGO=1;
		int a=ADRESL;
		int b=ADRESH*256;
		int c=a+b;
		c/=4;
		CCPR1L=c	;//duty cyle
	}	















































































































}