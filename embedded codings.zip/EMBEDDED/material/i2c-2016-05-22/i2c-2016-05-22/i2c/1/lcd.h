#include<pic.h>
void delay_1(unsigned int x)
 {
  while(x--);
 }
void lcd_init()
 {
  ADCON1=0X86;
  TRISD=0X00;
  TRISE=0X00;
  }
void lcd_command(unsigned char x)
 {
   PORTE=0X04;	
   PORTD=x;
   delay_1(10000);
   RE2=0;
 }
void lcd_data(unsigned char *x)
 {
   while(*x!='\0')
   {
    PORTE=0x05;
    PORTD=*x;
    delay_1(100);
    RE2=0;
    x++;
    delay_1(100);
   }
 }
void lcd_data1(unsigned char l)
 {
   PORTE=0X05;	
   PORTD=l;
   delay_1(100);
   RE2=0;
 }
void lcd_num(int y)
 {
   int remainder,a[10],i=0;
   RE0=1;
   delay_1(100);
	while(y>0)
	{
      remainder=y%10;
	  a[i]=remainder;
      y=y/10;
	  i++;
    }
	i--;
	while(i>=0)
	{
	  a[i]=a[i]+0x30;
	  delay_1(100);
	  delay_1(200);
	  RE2=1;
	  PORTD=a[i];
	  delay_1(100);
	  RE2=0;
	  i--;
	}
    
 }
