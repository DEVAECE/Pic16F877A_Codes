 #include<pic.h>
 #include"lcd.h"
char a[]={'g','o','w','t','h','a','m'};
int i;

#define _XTAL_FREQ 4000000
#define SDA RC4
#define SCK	RC3
#define SDA_DIR TRISC4		//Port C 4th pin
#define SCK_DIR	TRISC3		//Port C 3rd pin

unsigned char ab;
//#define I2C_SPEED 100
void delay(unsigned int d)
{
unsigned int i,j;
for(i=0;i<d;i++)
for(j=0;j<100;j++);
}



void I2C_init(void)
{
SDA_DIR=1;
SCK_DIR=1;

SSPADD=0X28;//100KHz for 4MHz clock
SSPSTAT=0X80;
SSPCON=0X28;
}
void I2C_start(void)
{
SEN=1;
while(SEN);

}

void I2C_stop(void)
{
PEN=1;
while(PEN);

}

void I2C_restart(void)
{
RSEN=1;
while(RSEN);
}



void I2C_ack()
{
ACKDT=0;
ACKEN=1;
while(ACKEN);
}

void I2C_nack()
{
ACKDT=1;
ACKEN=1;
while(ACKEN);
}
unsigned int I2C_write(unsigned char cc)
{
SSPBUF=cc;
while(SSPIF==0);
SSPIF=0;
//return ACKSTAT;
}

int I2C_send(unsigned int address,unsigned int data)
{
I2C_start();
delay(10);
I2C_write(0xA0);
delay(10);
//I2C_ack();
//delay(10);
//I2C_restart();
//delay(10);
I2C_write(address);
delay(10);
//I2C_restart();
//delay(10);
I2C_write(data);
delay(10);
I2C_stop();
}

unsigned char I2C_read(unsigned int address)
{
unsigned char byte;
I2C_start();
delay(10);
I2C_write(0xA0);
delay(10);
I2C_write(address);
delay(10);
I2C_write(0xA1);
RCEN=1;
delay(100);
byte=SSPBUF;
lcd_command(0x80);
lcd_data1(byte);
delay(100);
I2C_stop();
delay(10);
}
void main()
{
while(1)
{
  for(i=0;i<8;i++)
{
I2C_init();
delay(10);
I2C_send(0xA1,a[i]);
delay(1000);
I2C_read(0xA1);
}
}
}


