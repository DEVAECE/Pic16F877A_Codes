#include<pic.h>
void delay(unsigned int x)
{
	while(x--);
}
void main()
{
	char arr[6]="DEVA";
	int i;
	TRISC6=0;
	TRISC7=1;
	SPEN=1;
	TXSTA=0X26;
	RCSTA=0X90;
	SPBRG=129;
	while(1)
	{
		for (i=0;i<4;i++)
		{
			while(!TRMT);//while(!TXIF)
			TXREG=arr[i];
			delay(65000);
		}
	}
}