#include<pic.h>
void delay(unsigned int x)
{
	while(x--);
}
void main()
{
	int i;
	PORTB=0X00;
	TRISB=0X00;
	int n='C';
	TRISC6=0;
	TRISC7=1;
	TXSTA=0X26;
	RCSTA=0X90;
	SPBRG=129;
	while(1)
	{
		while(!TRMT);
		TXREG=n;
		delay(65000);
		while(!RCIF);
		RCIF=0;
		i=RCREG;
		PORTB=i;
		delay(65000);
	}
}
