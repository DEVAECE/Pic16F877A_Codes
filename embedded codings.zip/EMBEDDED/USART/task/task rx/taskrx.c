#include<pic.h>
void delay(unsigned int x)
{
	while(x--);
}

void main()
{
	int i;
	TRISB=0X00;
	PORTB=0X00;
	TRISC6=0;
	TRISC7=1;
	TXSTA=0X26;
	RCSTA=0X90;
	SPBRG=129;
	while(1)
	{
		while(!RCIF);
		RCIF=0;
		i=RCREG;
		PORTB=i;
		delay(65000);
		while(!TRMT);
		TXREG=i;
	}
}