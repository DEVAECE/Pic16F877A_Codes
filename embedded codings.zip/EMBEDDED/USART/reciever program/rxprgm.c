#include<pic.h>
void main()
{
	int i;
	TRISC6=0;
	TRISC7=1;
	TXSTA=0X26;
	RCSTA=0X90;
	SPBRG=129;
	while(1)
	{
		while(!RCIF);
		RCIF=0;
		i=RCREG;
		while(!TRMT);
		TXREG=i;
	}
}