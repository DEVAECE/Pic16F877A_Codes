#include<pic.h>
void delay(unsigned int x)
{
	while(x--);
}
void command(unsigned int z)
{
	RA0=0;
	RA1=1;
	PORTD=z;
	RA1=0;
	delay(650);
}
void data(unsigned char *dat)
{
	while(*dat!='\0')
	{
		RA0=1;
		RA1=1;
		PORTD=*dat;
		RA1=0;
		delay(650);
		dat++;
	}
}

void data1(unsigned char dt)
{
		RA0=1;
		RA1=1;
		PORTD=dt;
		RA1=0;
		delay(650);	
}
void main()
{
	int i=0;
	char arr;
	TRISA=0X00;
	PORTA=0X00;
	PORTB=0X00;
	TRISB=0X00;
	PORTD=0X00;
	TRISD=0X00;
	command(0X38);
	command(0X06);
	command(0X0C);
	command(0X01);
	TRISC6=0;
	TRISC7=1;
	TXSTA=0X26;
	RCSTA=0X90;
	SPBRG=129;
	ADCON1=0X87;
	/*command(0X80);
	data(&arr);
	command(0XC0);
	data("working");
	delay(65000);*/
	while(1)
	{
		while(!RCIF);
		RCIF=0;
		arr=RCREG;
		command(0X80+i);
		PORTB=arr;
		data1(arr);
         i++;
		delay(650);
      if(i>16)
		{
			command(0x01);
			i=0;

		}
	}
}
	

		