#include<pic.h>
	int i=0;
	unsigned char a;
void slave_set()
{
	ADCON1=0X87;
	TRISC4=1;
	TRISC5=0;
	TRISC3=1;
	TRISA5=1;
	SSPSTAT=0X40;
	SSPCON=0X24;
}
void slave_rx()
{
		while(BF==0);
		a=SSPBUF;
		lcd_command(0XC0+i);
		lcd_sdata(a);
		delay(6500);
		delay(6500);
		i++;
		if(i>16)
		{
			lcd_command(0x01);
			i=0;
		}
}