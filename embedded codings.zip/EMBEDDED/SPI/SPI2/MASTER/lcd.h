#include<pic.h>
void delay(unsigned int x)
{
	while(x--);
}
void lcd_init()
{
	ADCON1=0X87;
	TRISD=0X00;
	TRISE=0X00;
}
void lcd_command(unsigned int z)
{
	RE0=0;
	RE1=1;
	PORTD=z;
	RE1=0;
	delay(10000);
}
void lcd_data(unsigned char *dat)
{
	while(*dat!='\0')
	{
		RE0=1;
		RE1=1;
		PORTD=*dat;
		delay(10000);
		RE1=0;
		dat++;
		delay(10000);
		delay(10000);
	}
}
void lcd_sdata(unsigned char dt)
{
	RE0=1;
	RE1=1;
	PORTD=dt;
	delay(10000);
	RE1=0;
}
void lcd_num(int j)
{
	int i=0;
	int a[3];
	while(i<3)
	{
		a[i]=j%10;
		j=j/10;
		i++;
	}
	i--;
	while(i>=0)
	{
		RE0=1;
		PORTD=a[i]+0X30;
		RE1=1;
		delay(10000);
		delay(200);
		RE1=0;
		i--;
	}
}

		
