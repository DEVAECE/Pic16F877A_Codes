#include<pic.h>
void master_set()
{
	ADCON1=0X87;
	TRISC4=1;
	TRISC5=0;
	TRISC3=0;
	TRISA=0X00;
	SSPSTAT=0X40;
	SSPCON=0X20;
}
void master_tx(unsigned char *j)
{
	while(*j!='\0')
	{
		SSPSTAT=0X40;
		while(BF==1);
		SSPBUF=*j;
		while(BF);
		delay(65000);
		delay(65000);
		j++;
	}
}