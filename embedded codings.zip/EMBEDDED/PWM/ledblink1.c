#include<pic.h>
void delay(unsigned int x)
{
	while(x--);
}
void main()
{
	TRISB=0X00;
	PORTB=0X00;
	while(1)
	{
		RB0=1;
		delay(65000);
		RB0=0;
		delay(65000);
	
	}
}