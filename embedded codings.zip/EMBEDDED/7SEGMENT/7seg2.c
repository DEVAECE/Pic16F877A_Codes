#include<pic.h>
char a[10]={0X3F,0X06,0X5B,0X4F,0X66,0X6D,0X7D,0X07,0X7F,0X6F};
void delay(unsigned int x)
{
	while(x--);
}
void main()
{
	TRISC=0X00;
	TRISD=0X00;
	PORTD=0X00;
	PORTC=0X00;
	int i,b,c;
	while(1)
	{
		for(i=0;i<100;i++)
		{
			b=i/10;
			c=i%10;
			RD0=0;
			PORTC=a[b];
			delay(65000);
			RD0=1;
			RD1=0;
			PORTC=a[c];
			delay(65000);
			RD1=1;
		}
	}
}